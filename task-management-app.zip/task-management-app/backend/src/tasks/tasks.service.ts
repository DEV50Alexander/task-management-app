import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Task, TaskDocument, TaskStatus } from './schemas/task.schema';
import { CreateTaskDto } from './dto/create-task.dto';
import { UsersService } from '../users/users.service';

@Injectable()
export class TasksService {
  constructor(
    @InjectModel(Task.name) private readonly taskModel: Model<TaskDocument>,
    private readonly usersService: UsersService,
  ) {}

  async create(createTaskDto: CreateTaskDto): Promise<Task> {
    // Verify user exists
    await this.usersService.findOne(createTaskDto.userId);
    
    const createdTask = new this.taskModel(createTaskDto);
    return createdTask.save();
  }

  async findAll(page = 1, limit = 10, status?: TaskStatus): Promise<{ tasks: Task[]; total: number }> {
    const query = status ? { status } : {};
    const skip = (page - 1) * limit;
    
    const [tasks, total] = await Promise.all([
      this.taskModel
        .find(query)
        .populate('userId', 'name email')
        .skip(skip)
        .limit(limit)
        .exec(),
      this.taskModel.countDocuments(query),
    ]);
    
    return { tasks, total };
  }

  async findOne(id: string): Promise<Task> {
    const task = await this.taskModel
      .findById(id)
      .populate('userId', 'name email')
      .exec();
    if (!task) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }
    return task;
  }

  async update(id: string, updateTaskDto: CreateTaskDto): Promise<Task> {
    if (updateTaskDto.userId) {
      // Verify user exists if userId is being updated
      await this.usersService.findOne(updateTaskDto.userId);
    }

    const updatedTask = await this.taskModel
      .findByIdAndUpdate(id, updateTaskDto, { new: true })
      .populate('userId', 'name email')
      .exec();
    
    if (!updatedTask) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }
    return updatedTask;
  }

  async remove(id: string): Promise<void> {
    const result = await this.taskModel.deleteOne({ _id: id }).exec();
    if (result.deletedCount === 0) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }
  }

  async findByUser(userId: string, page = 1, limit = 10): Promise<{ tasks: Task[]; total: number }> {
    const skip = (page - 1) * limit;
    
    const [tasks, total] = await Promise.all([
      this.taskModel
        .find({ userId })
        .populate('userId', 'name email')
        .skip(skip)
        .limit(limit)
        .exec(),
      this.taskModel.countDocuments({ userId }),
    ]);
    
    return { tasks, total };
  }
}
