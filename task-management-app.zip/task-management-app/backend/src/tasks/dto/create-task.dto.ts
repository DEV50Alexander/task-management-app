import { IsNotEmpty, IsString, IsEnum, IsOptional } from 'class-validator';
import { TaskStatus } from '../schemas/task.schema';

export class CreateTaskDto {
  @IsString()
  @IsNotEmpty()
  readonly title: string;

  @IsString()
  @IsOptional()
  readonly description?: string;

  @IsString()
  @IsNotEmpty()
  readonly userId: string;

  @IsEnum(TaskStatus)
  @IsOptional()
  readonly status?: TaskStatus;
}
